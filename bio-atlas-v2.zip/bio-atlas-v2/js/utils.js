/**
 * أدوات مساعدة
 */
const Utils = (() => {
  const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

  function generateCode(length = 8) {
    let code = 'BIO-';
    for (let i = 0; i < length; i++) {
      code += CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)];
    }
    return code;
  }

  function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str ?? '';
    return div.innerHTML;
  }

  /**
   * مقارنة ذكية للمسمّيات
   * - تتجاهل التشكيل
   * - تتجاهل المسافات الزائدة
   * - تسمح بخطأ حرف واحد (Levenshtein ≤ 1)
   */
  function normalizeArabic(str) {
    return (str || '')
      .trim()
      .replace(/[\u064B-\u065F\u0670]/g, '') // حذف التشكيل
      .replace(/ى/g, 'ي')
      .replace(/ة/g, 'ه')
      .replace(/أ|إ|آ/g, 'ا')
      .replace(/\s+/g, ' ')
      .toLowerCase();
  }

  function levenshtein(a, b) {
    const m = a.length, n = b.length;
    const dp = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        dp[i][j] = a[i - 1] === b[j - 1]
          ? dp[i - 1][j - 1]
          : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
      }
    }
    return dp[m][n];
  }

  function isAnswerCorrect(userAnswer, correctAnswer) {
    const u = normalizeArabic(userAnswer);
    const c = normalizeArabic(correctAnswer);
    if (!u || !c) return false;
    if (u === c) return true;
    // تسامح بحرف واحد إذا كان الطول معقول
    if (Math.abs(u.length - c.length) <= 1 && levenshtein(u, c) <= 1) {
      return true;
    }
    return false;
  }

  function debounce(fn, wait = 300) {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), wait);
    };
  }

  return {
    generateCode,
    generateId,
    escapeHtml,
    normalizeArabic,
    isAnswerCorrect,
    debounce,
  };
})();
