/**
 * منطق المعلم بالكامل
 */
const Teacher = (() => {
  const state = {
    classId: null,
    unitId: null,
    sectionId: null,
    lessonId: null,
    diagramId: null,
    currentLabels: [],
    selectedColor: '#1B5E3B',
    isDrawing: false,
    drawStart: null,
  };

  function init() {
    initLogin();
    initTabs();
    initClasses();
    initUnits();
    initSections();
    initLessons();
    initDiagrams();
    initDiagramEditor();
    initCodes();
    initSettings();
    initLogout();
  }

  // ---------- تسجيل الدخول ----------
  function initLogin() {
    document.getElementById('form-teacher-login').addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('input-teacher-email').value.trim();
      const password = document.getElementById('input-teacher-password').value;
      const errorEl = document.getElementById('teacher-login-error');
      errorEl.classList.add('hidden');

      UI.showLoading('جارٍ تسجيل الدخول…');
      try {
        await Auth.teacherSignIn(email, password);
        // onAuthChange راح يتكفل بالدخول
      } catch (err) {
        errorEl.textContent = 'البريد أو كلمة السر غير صحيحة';
        errorEl.classList.remove('hidden');
      } finally {
        UI.hideLoading();
      }
    });
  }

  function initLogout() {
    document.getElementById('btn-teacher-logout').addEventListener('click', async () => {
      await Auth.teacherSignOut();
      Router.show('screen-teacher-login', { resetHistory: true });
    });
  }

  async function enterDashboard(user) {
    document.getElementById('teacher-email-label').textContent = user.email || '';
    Router.show('screen-teacher-dashboard', { resetHistory: true });
    loadClasses();
    loadCodes();
    loadStats();
  }

  // ---------- التبويبات ----------
  function initTabs() {
    document.querySelectorAll('#screen-teacher-dashboard .tab').forEach((tab) => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('#screen-teacher-dashboard .tab').forEach((t) => t.classList.remove('active'));
        document.querySelectorAll('#screen-teacher-dashboard .panel').forEach((p) => p.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(tab.dataset.panel).classList.add('active');

        if (tab.dataset.panel === 'panel-stats') loadStats();
        if (tab.dataset.panel === 'panel-codes') loadCodes();
      });
    });
  }

  // ---------- الصفوف ----------
  function initClasses() {
    document.getElementById('btn-add-class').addEventListener('click', async () => {
      const name = await UI.promptDialog('إضافة صف جديد', 'اسم الصف');
      if (!name) return;
      UI.showLoading();
      try {
        await DB.addClass(name);
        UI.toast('تمت إضافة الصف');
        loadClasses();
      } catch (err) {
        UI.toast(err.message || 'حدث خطأ', 'error');
      } finally {
        UI.hideLoading();
      }
    });

    document.getElementById('btn-delete-class').addEventListener('click', async () => {
      if (!confirm('هل أنت متأكد من حذف الصف وكل محتوياته؟')) return;
      UI.showLoading();
      try {
        await DB.deleteClass(state.classId);
        UI.toast('تم حذف الصف');
        Router.back();
        loadClasses();
      } catch (err) {
        UI.toast(err.message || 'حدث خطأ', 'error');
      } finally {
        UI.hideLoading();
      }
    });
  }

  async function loadClasses() {
    UI.showLoading();
    try {
      const classes = await DB.getClasses();
      const list = document.getElementById('list-classes');
      list.innerHTML = '';
      document.getElementById('empty-classes').classList.toggle('hidden', classes.length > 0);

      classes.forEach((c) => {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `
          <div>
            <div class="list-item-title">${Utils.escapeHtml(c.name)}</div>
          </div>
          <span class="list-item-arrow">‹</span>`;
        li.addEventListener('click', () => openClass(c.id, c.name));
        list.appendChild(li);
      });
    } catch (err) {
      UI.toast('تعذر تحميل الصفوف', 'error');
    } finally {
      UI.hideLoading();
    }
  }

  function openClass(id, name) {
    state.classId = id;
    document.getElementById('teacher-class-title').textContent = name;
    Router.show('screen-teacher-class');
    loadUnits();
  }

  // ---------- الوحدات ----------
  function initUnits() {
    document.getElementById('btn-add-unit').addEventListener('click', async () => {
      const name = await UI.promptDialog('إضافة وحدة', 'اسم الوحدة');
      if (!name) return;
      UI.showLoading();
      try {
        await DB.addUnit(state.classId, name);
        UI.toast('تمت الإضافة');
        loadUnits();
      } catch (err) {
        UI.toast(err.message || 'خطأ', 'error');
      } finally {
        UI.hideLoading();
      }
    });

    document.getElementById('btn-delete-unit').addEventListener('click', async () => {
      if (!confirm('حذف الوحدة وكل أقسامها؟')) return;
      UI.showLoading();
      try {
        await DB.deleteUnit(state.unitId);
        UI.toast('تم الحذف');
        Router.back();
      } catch (err) {
        UI.toast(err.message || 'خطأ', 'error');
      } finally {
        UI.hideLoading();
      }
    });
  }

  async function loadUnits() {
    UI.showLoading();
    try {
      const units = await DB.getUnits(state.classId);
      const list = document.getElementById('list-units');
      list.innerHTML = '';
      document.getElementById('empty-units').classList.toggle('hidden', units.length > 0);

      units.forEach((u) => {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `
          <div><div class="list-item-title">${Utils.escapeHtml(u.name)}</div></div>
          <span class="list-item-arrow">‹</span>`;
        li.addEventListener('click', () => openUnit(u.id, u.name));
        list.appendChild(li);
      });
    } catch (err) {
      UI.toast('تعذر التحميل', 'error');
    } finally {
      UI.hideLoading();
    }
  }

  function openUnit(id, name) {
    state.unitId = id;
    document.getElementById('teacher-unit-title').textContent = name;
    Router.show('screen-teacher-unit');
    loadSections();
  }

  // ---------- الأقسام ----------
  function initSections() {
    document.getElementById('btn-add-section').addEventListener('click', async () => {
      const name = await UI.promptDialog('إضافة قسم', 'اسم القسم');
      if (!name) return;
      UI.showLoading();
      try {
        await DB.addSection(state.unitId, name);
        UI.toast('تمت الإضافة');
        loadSections();
      } catch (err) {
        UI.toast(err.message || 'خطأ', 'error');
      } finally {
        UI.hideLoading();
      }
    });

    document.getElementById('btn-delete-section').addEventListener('click', async () => {
      if (!confirm('حذف القسم وكل دروسه؟')) return;
      UI.showLoading();
      try {
        await DB.deleteSection(state.sectionId);
        UI.toast('تم الحذف');
        Router.back();
      } catch (err) {
        UI.toast(err.message || 'خطأ', 'error');
      } finally {
        UI.hideLoading();
      }
    });
  }

  async function loadSections() {
    UI.showLoading();
    try {
      const sections = await DB.getSections(state.unitId);
      const list = document.getElementById('list-sections');
      list.innerHTML = '';
      document.getElementById('empty-sections').classList.toggle('hidden', sections.length > 0);

      sections.forEach((s) => {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `
          <div><div class="list-item-title">${Utils.escapeHtml(s.name)}</div></div>
          <span class="list-item-arrow">‹</span>`;
        li.addEventListener('click', () => openSection(s.id, s.name));
        list.appendChild(li);
      });
    } catch (err) {
      UI.toast('تعذر التحميل', 'error');
    } finally {
      UI.hideLoading();
    }
  }

  function openSection(id, name) {
    state.sectionId = id;
    document.getElementById('teacher-section-title').textContent = name;
    Router.show('screen-teacher-section');
    loadLessons();
  }

  // ---------- الدروس ----------
  function initLessons() {
    document.getElementById('btn-add-lesson').addEventListener('click', async () => {
      const name = await UI.promptDialog('إضافة درس', 'اسم الدرس');
      if (!name) return;
      UI.showLoading();
      try {
        await DB.addLesson(state.sectionId, name);
        UI.toast('تمت الإضافة');
        loadLessons();
      } catch (err) {
        UI.toast(err.message || 'خطأ', 'error');
      } finally {
        UI.hideLoading();
      }
    });

    document.getElementById('btn-delete-lesson').addEventListener('click', async () => {
      if (!confirm('حذف الدرس وكل رسوماته؟')) return;
      UI.showLoading();
      try {
        await DB.deleteLesson(state.lessonId);
        UI.toast('تم الحذف');
        Router.back();
      } catch (err) {
        UI.toast(err.message || 'خطأ', 'error');
      } finally {
        UI.hideLoading();
      }
    });
  }

  async function loadLessons() {
    UI.showLoading();
    try {
      const lessons = await DB.getLessons(state.sectionId);
      const list = document.getElementById('list-lessons');
      list.innerHTML = '';
      document.getElementById('empty-lessons').classList.toggle('hidden', lessons.length > 0);

      lessons.forEach((l) => {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `
          <div>
            <div class="list-item-title">${Utils.escapeHtml(l.name)}</div>
            <div class="list-item-sub">${l.views || 0} مشاهدة</div>
          </div>
          <span class="list-item-arrow">‹</span>`;
        li.addEventListener('click', () => openLesson(l.id, l.name));
        list.appendChild(li);
      });
    } catch (err) {
      UI.toast('تعذر التحميل', 'error');
    } finally {
      UI.hideLoading();
    }
  }

  function openLesson(id, name) {
    state.lessonId = id;
    document.getElementById('teacher-lesson-title').textContent = name;
    Router.show('screen-teacher-lesson');
    loadDiagrams();
  }

  // ---------- الرسومات ----------
  function initDiagrams() {
    document.getElementById('btn-add-diagram').addEventListener('click', () => {
      state.diagramId = null;
      state.currentLabels = [];
      document.getElementById('input-diagram-name').value = '';
      document.getElementById('diagram-image').src = '';
      document.getElementById('diagram-stage').classList.add('hidden');
      document.getElementById('no-image-msg').classList.remove('hidden');
      document.getElementById('labels-layer').innerHTML = '';
      Router.show('screen-teacher-diagram-editor');
    });

    document.getElementById('btn-delete-lesson'); // already handled
  }

  async function loadDiagrams() {
    UI.showLoading();
    try {
      const diagrams = await DB.getDiagrams(state.lessonId);
      const list = document.getElementById('list-diagrams');
      list.innerHTML = '';
      document.getElementById('empty-diagrams').classList.toggle('hidden', diagrams.length > 0);

      diagrams.forEach((d) => {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `
          <div>
            <div class="list-item-title">${Utils.escapeHtml(d.name || 'رسمة')}</div>
            <div class="list-item-sub">${(d.labels || []).length} مسمّى</div>
          </div>
          <span class="list-item-arrow">‹</span>`;
        li.addEventListener('click', () => openDiagramEditor(d));
        list.appendChild(li);
      });
    } catch (err) {
      UI.toast('تعذر التحميل', 'error');
    } finally {
      UI.hideLoading();
    }
  }

  function openDiagramEditor(diagram) {
    state.diagramId = diagram.id;
    state.currentLabels = Array.isArray(diagram.labels) ? [...diagram.labels] : [];
    document.getElementById('input-diagram-name').value = diagram.name || '';
    document.getElementById('diagram-image').src = diagram.image_url;
    document.getElementById('diagram-stage').classList.remove('hidden');
    document.getElementById('no-image-msg').classList.add('hidden');
    renderLabels();
    Router.show('screen-teacher-diagram-editor');
  }

  // ---------- محرر الرسمة ----------
  function initDiagramEditor() {
    // اختيار اللون
    document.querySelectorAll('.color-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.color-btn').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        state.selectedColor = btn.dataset.color;
      });
    });

    // رفع صورة
    document.getElementById('btn-upload-image').addEventListener('click', () => {
      document.getElementById('input-image-file').click();
    });

    document.getElementById('input-image-file').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      UI.showLoading('جارٍ رفع الصورة…');
      try {
        const url = await DB.uploadImage(file);
        document.getElementById('diagram-image').src = url;
        document.getElementById('diagram-stage').classList.remove('hidden');
        document.getElementById('no-image-msg').classList.add('hidden');
        state.currentLabels = [];
        renderLabels();
        UI.toast('تم رفع الصورة');
      } catch (err) {
        UI.toast(err.message || 'فشل الرفع', 'error');
      } finally {
        UI.hideLoading();
        e.target.value = '';
      }
    });

    // رسم الشريط (من الأعلى)
    const stage = document.getElementById('diagram-stage');
    const layer = document.getElementById('labels-layer');

    stage.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.label-bar') && !e.target.classList.contains('drawing')) return;
      const img = document.getElementById('diagram-image');
      if (!img.src) return;

      const rect = img.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;

      state.isDrawing = true;
      state.drawStart = { x, y };

      const bar = document.createElement('div');
      bar.className = 'label-bar drawing';
      bar.style.background = state.selectedColor;
      bar.style.left = x + '%';
      bar.style.top = y + '%';
      bar.style.width = '0%';
      bar.style.height = '0%';
      bar.dataset.temp = '1';
      layer.appendChild(bar);
    });

    stage.addEventListener('pointermove', (e) => {
      if (!state.isDrawing) return;
      const img = document.getElementById('diagram-image');
      const rect = img.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;

      const bar = layer.querySelector('[data-temp="1"]');
      if (!bar) return;

      const left = Math.min(state.drawStart.x, x);
      const top = Math.min(state.drawStart.y, y);
      const w = Math.abs(x - state.drawStart.x);
      const h = Math.abs(y - state.drawStart.y);

      bar.style.left = left + '%';
      bar.style.top = top + '%';
      bar.style.width = w + '%';
      bar.style.height = h + '%';
    });

    stage.addEventListener('pointerup', async (e) => {
      if (!state.isDrawing) return;
      state.isDrawing = false;

      const bar = layer.querySelector('[data-temp="1"]');
      if (!bar) return;

      const w = parseFloat(bar.style.width);
      const h = parseFloat(bar.style.height);

      if (w < 3 || h < 2) {
        bar.remove();
        return;
      }

      bar.removeAttribute('data-temp');
      bar.classList.remove('drawing');

      // طلب النص من المعلم
      const text = await UI.promptDialog('اكتب المسمّى الصحيح', 'المسمّى الذي يغطي الشريط');
      if (!text) {
        bar.remove();
        return;
      }

      const label = {
        id: Utils.generateId(),
        xPct: parseFloat(bar.style.left),
        yPct: parseFloat(bar.style.top),
        wPct: w,
        hPct: h,
        text: text,
        color: state.selectedColor,
      };

      state.currentLabels.push(label);
      renderLabels();
    });

    document.getElementById('btn-clear-labels').addEventListener('click', () => {
      if (!confirm('مسح كل الشرائط؟')) return;
      state.currentLabels = [];
      renderLabels();
    });

    document.getElementById('btn-undo-label').addEventListener('click', () => {
      state.currentLabels.pop();
      renderLabels();
    });

    document.getElementById('btn-save-diagram').addEventListener('click', async () => {
      const name = document.getElementById('input-diagram-name').value.trim() || 'رسمة';
      const img = document.getElementById('diagram-image');
      if (!img.src || img.src === window.location.href) {
        UI.toast('ارفع صورة أولاً', 'error');
        return;
      }

      UI.showLoading('جارٍ الحفظ…');
      try {
        if (state.diagramId) {
          await DB.updateDiagram(state.diagramId, {
            name,
            image_url: img.src,
            labels: state.currentLabels,
          });
        } else {
          await DB.addDiagram(state.lessonId, {
            name,
            image_url: img.src,
            labels: state.currentLabels,
          });
        }
        UI.toast('تم الحفظ بنجاح');
        Router.back();
        loadDiagrams();
      } catch (err) {
        UI.toast(err.message || 'فشل الحفظ', 'error');
      } finally {
        UI.hideLoading();
      }
    });
  }

  function renderLabels() {
    const layer = document.getElementById('labels-layer');
    layer.innerHTML = '';
    state.currentLabels.forEach((label) => {
      const bar = document.createElement('div');
      bar.className = 'label-bar';
      bar.style.left = label.xPct + '%';
      bar.style.top = label.yPct + '%';
      bar.style.width = label.wPct + '%';
      bar.style.height = label.hPct + '%';
      bar.style.background = label.color || '#1B5E3B';
      bar.title = label.text;
      bar.textContent = label.text.length > 12 ? label.text.slice(0, 10) + '…' : label.text;

      // حذف بالنقر المزدوج
      bar.addEventListener('dblclick', () => {
        state.currentLabels = state.currentLabels.filter((l) => l.id !== label.id);
        renderLabels();
      });

      layer.appendChild(bar);
    });
  }

  // ---------- الأكواد ----------
  function initCodes() {
    document.getElementById('btn-generate-code').addEventListener('click', async () => {
      const note = await UI.promptDialog('توليد كود جديد', 'اسم الطالب أو ملاحظة (اختياري)');
      UI.showLoading('جارٍ التوليد…');
      try {
        const code = await DB.generateCode(note || '');
        UI.toast('تم توليد الكود: ' + code.code);
        loadCodes();
      } catch (err) {
        UI.toast(err.message || 'فشل التوليد', 'error');
      } finally {
        UI.hideLoading();
      }
    });
  }

  async function loadCodes() {
    try {
      const codes = await DB.getCodes();
      document.getElementById('codes-count').textContent = codes.length;
      const list = document.getElementById('list-codes');
      list.innerHTML = '';
      document.getElementById('empty-codes').classList.toggle('hidden', codes.length > 0);

      codes.forEach((c) => {
        const li = document.createElement('li');
        li.className = 'list-item code-item';
        const usedBadge = c.used
          ? '<span class="badge badge-used">مستخدم</span>'
          : '<span class="badge badge-unused">غير مستخدم</span>';
        const activeText = c.active === false ? ' (معطّل)' : '';

        li.innerHTML = `
          <div>
            <div class="code-value">${Utils.escapeHtml(c.code)}</div>
            <div class="list-item-sub">${Utils.escapeHtml(c.note || 'بدون ملاحظة')}${activeText} ${usedBadge}</div>
          </div>
          <div class="code-actions">
            <button class="btn btn-ghost btn-sm" data-action="edit">تعديل</button>
            <button class="btn btn-ghost btn-sm" data-action="toggle">${c.active === false ? 'تفعيل' : 'تعطيل'}</button>
            <button class="btn btn-danger-ghost btn-sm" data-action="delete">حذف</button>
          </div>`;

        li.querySelector('[data-action="edit"]').addEventListener('click', async () => {
          const newNote = await UI.promptDialog('تعديل الملاحظة', 'اسم الطالب', c.note || '');
          if (newNote === null) return;
          await DB.updateCode(c.id, { note: newNote });
          UI.toast('تم التعديل');
          loadCodes();
        });

        li.querySelector('[data-action="toggle"]').addEventListener('click', async () => {
          await DB.updateCode(c.id, { active: c.active === false });
          loadCodes();
        });

        li.querySelector('[data-action="delete"]').addEventListener('click', async () => {
          if (!confirm('حذف الكود؟')) return;
          await DB.deleteCode(c.id);
          UI.toast('تم الحذف');
          loadCodes();
        });

        list.appendChild(li);
      });
    } catch (err) {
      UI.toast('تعذر تحميل الأكواد', 'error');
    }
  }

  // ---------- الإحصائيات ----------
  async function loadStats() {
    try {
      const stats = await DB.getStats();
      document.getElementById('stat-total-codes').textContent = stats.totalCodes;
      document.getElementById('stat-used-codes').textContent = stats.usedCodes;

      const popList = document.getElementById('list-popular-lessons');
      popList.innerHTML = '';
      document.getElementById('empty-popular').classList.toggle('hidden', stats.popularLessons.length > 0);
      stats.popularLessons.forEach((l) => {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `
          <div class="list-item-title">${Utils.escapeHtml(l.name)}</div>
          <div class="list-item-sub">${l.views || 0} مشاهدة</div>`;
        popList.appendChild(li);
      });

      const errList = document.getElementById('list-error-diagrams');
      errList.innerHTML = '';
      document.getElementById('empty-errors-stats').classList.toggle('hidden', stats.errorDiagrams.length > 0);
      stats.errorDiagrams.forEach((d) => {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `
          <div class="list-item-title">${Utils.escapeHtml(d.name || 'رسمة')}</div>
          <div class="list-item-sub">${d.error_count || 0} خطأ</div>`;
        errList.appendChild(li);
      });
    } catch (err) {
      console.error(err);
    }
  }

  // ---------- الإعدادات ----------
  function initSettings() {
    document.getElementById('form-change-password').addEventListener('submit', async (e) => {
      e.preventDefault();
      const newPass = document.getElementById('input-new-password').value;
      const msg = document.getElementById('password-change-msg');
      UI.showLoading();
      try {
        await Auth.changePassword(newPass);
        msg.textContent = 'تم تغيير كلمة السر بنجاح';
        msg.classList.remove('hidden');
        document.getElementById('form-change-password').reset();
      } catch (err) {
        UI.toast(err.message || 'فشل التغيير', 'error');
      } finally {
        UI.hideLoading();
      }
    });
  }

  return { init, enterDashboard };
})();
