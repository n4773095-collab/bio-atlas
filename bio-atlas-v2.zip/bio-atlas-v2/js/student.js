/**
 * منطق الطالب بالكامل
 */
const Student = (() => {
  const state = {
    code: null,
    classId: null,
    unitId: null,
    sectionId: null,
    lessonId: null,
    currentDiagram: null,
    solvedLabels: new Set(),
  };

  function init() {
    initLogin();
    initNavigation();
    initDiagramView();
    initErrors();
  }

  function initLogin() {
    document.getElementById('form-student-login').addEventListener('submit', async (e) => {
      e.preventDefault();
      const raw = document.getElementById('input-student-code').value.trim().toUpperCase();
      const errorEl = document.getElementById('student-login-error');
      errorEl.classList.add('hidden');

      if (!raw) return;

      UI.showLoading('جارٍ التحقق…');
      try {
        const codeData = await DB.validateCode(raw);
        if (!codeData) {
          errorEl.textContent = 'الكود غير صحيح أو غير مفعّل';
          errorEl.classList.remove('hidden');
          return;
        }

        // تعليم الكود كمستخدم
        if (!codeData.used) {
          await DB.markCodeUsed(codeData.id);
        }

        Auth.setStudentCode(raw, codeData.id);
        state.code = raw;
        enterClasses();
      } catch (err) {
        errorEl.textContent = 'تعذر التحقق، تأكد من الإنترنت';
        errorEl.classList.remove('hidden');
      } finally {
        UI.hideLoading();
      }
    });

    document.getElementById('btn-open-teacher-login').addEventListener('click', () => {
      Router.show('screen-teacher-login');
    });

    document.getElementById('btn-student-logout').addEventListener('click', () => {
      Auth.clearStudentCode();
      state.code = null;
      Router.show('screen-student-login', { resetHistory: true });
    });
  }

  async function enterClasses() {
    state.code = Auth.getStudentCode();
    Router.show('screen-student-classes', { resetHistory: true });
    UI.showLoading();
    try {
      const classes = await DB.getClasses();
      const list = document.getElementById('list-student-classes');
      list.innerHTML = '';
      document.getElementById('empty-student-classes').classList.toggle('hidden', classes.length > 0);

      classes.forEach((c) => {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `
          <div class="list-item-title">${Utils.escapeHtml(c.name)}</div>
          <span class="list-item-arrow">‹</span>`;
        li.addEventListener('click', () => openClass(c.id, c.name));
        list.appendChild(li);
      });
    } catch (err) {
      UI.toast('تعذر التحميل', 'error');
    } finally {
      UI.hideLoading();
    }
  }

  function initNavigation() {
    // يتم الربط من خلال الدوال
  }

  async function openClass(id, name) {
    state.classId = id;
    document.getElementById('student-units-title').textContent = name;
    Router.show('screen-student-units');
    UI.showLoading();
    try {
      const units = await DB.getUnits(id);
      const list = document.getElementById('list-student-units');
      list.innerHTML = '';
      document.getElementById('empty-student-units').classList.toggle('hidden', units.length > 0);

      units.forEach((u) => {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `
          <div class="list-item-title">${Utils.escapeHtml(u.name)}</div>
          <span class="list-item-arrow">‹</span>`;
        li.addEventListener('click', () => openUnit(u.id, u.name));
        list.appendChild(li);
      });
    } catch (err) {
      UI.toast('تعذر التحميل', 'error');
    } finally {
      UI.hideLoading();
    }
  }

  async function openUnit(id, name) {
    state.unitId = id;
    document.getElementById('student-sections-title').textContent = name;
    Router.show('screen-student-sections');
    UI.showLoading();
    try {
      const sections = await DB.getSections(id);
      const list = document.getElementById('list-student-sections');
      list.innerHTML = '';
      document.getElementById('empty-student-sections').classList.toggle('hidden', sections.length > 0);

      sections.forEach((s) => {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `
          <div class="list-item-title">${Utils.escapeHtml(s.name)}</div>
          <span class="list-item-arrow">‹</span>`;
        li.addEventListener('click', () => openSection(s.id, s.name));
        list.appendChild(li);
      });
    } catch (err) {
      UI.toast('تعذر التحميل', 'error');
    } finally {
      UI.hideLoading();
    }
  }

  async function openSection(id, name) {
    state.sectionId = id;
    document.getElementById('student-lessons-title').textContent = name;
    Router.show('screen-student-lessons');
    UI.showLoading();
    try {
      const lessons = await DB.getLessons(id);
      const list = document.getElementById('list-student-lessons');
      list.innerHTML = '';
      document.getElementById('empty-student-lessons').classList.toggle('hidden', lessons.length > 0);

      lessons.forEach((l) => {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `
          <div class="list-item-title">${Utils.escapeHtml(l.name)}</div>
          <span class="list-item-arrow">‹</span>`;
        li.addEventListener('click', () => openLesson(l.id, l.name));
        list.appendChild(li);
      });
    } catch (err) {
      UI.toast('تعذر التحميل', 'error');
    } finally {
      UI.hideLoading();
    }
  }

  async function openLesson(id, name) {
    state.lessonId = id;
    document.getElementById('student-diagrams-title').textContent = name;
    Router.show('screen-student-diagrams');

    // زيادة المشاهدات
    DB.incrementLessonViews(id).catch(() => {});

    UI.showLoading();
    try {
      const diagrams = await DB.getDiagrams(id);
      const list = document.getElementById('list-student-diagrams');
      list.innerHTML = '';
      document.getElementById('empty-student-diagrams').classList.toggle('hidden', diagrams.length > 0);

      diagrams.forEach((d) => {
        const li = document.createElement('li');
        li.className = 'list-item';
        li.innerHTML = `
          <div class="list-item-title">${Utils.escapeHtml(d.name || 'رسمة')}</div>
          <span class="list-item-arrow">‹</span>`;
        li.addEventListener('click', () => openDiagram(d));
        list.appendChild(li);
      });
    } catch (err) {
      UI.toast('تعذر التحميل', 'error');
    } finally {
      UI.hideLoading();
    }
  }

  function openDiagram(diagram) {
    state.currentDiagram = diagram;
    state.solvedLabels = new Set();
    document.getElementById('student-diagram-view-title').textContent = diagram.name || 'الرسمة';
    document.getElementById('student-diagram-image').src = diagram.image_url;
    renderStudentLabels();
    Router.show('screen-student-diagram-view');
  }

  function initDiagramView() {
    document.getElementById('btn-reset-diagram').addEventListener('click', () => {
      state.solvedLabels = new Set();
      renderStudentLabels();
    });
  }

  function renderStudentLabels() {
    const layer = document.getElementById('student-labels-layer');
    layer.innerHTML = '';
    const labels = state.currentDiagram?.labels || [];

    labels.forEach((label) => {
      const bar = document.createElement('div');
      bar.className = 'label-bar' + (state.solvedLabels.has(label.id) ? ' solved' : '');
      bar.style.left = label.xPct + '%';
      bar.style.top = label.yPct + '%';
      bar.style.width = label.wPct + '%';
      bar.style.height = label.hPct + '%';
      bar.style.background = label.color || '#1B5E3B';

      if (!state.solvedLabels.has(label.id)) {
        bar.addEventListener('click', () => handleLabelClick(label, bar));
      } else {
        bar.textContent = label.text;
      }

      layer.appendChild(bar);
    });
  }

  async function handleLabelClick(label, barEl) {
    const answer = await UI.askAnswer();
    if (answer === null) return;

    const correct = Utils.isAnswerCorrect(answer, label.text);

    if (correct) {
      UI.showAnswerFeedback(true);
      UI.confetti();
      state.solvedLabels.add(label.id);
      setTimeout(() => {
        document.getElementById('answer-modal').classList.add('hidden');
        renderStudentLabels();

        // إذا خلص كل المسمّيات، نشيلها من الأخطاء
        const total = (state.currentDiagram.labels || []).length;
        if (state.solvedLabels.size >= total) {
          DB.removeStudentError(state.code, state.currentDiagram.id);
          UI.toast('أحسنت! أكملت الرسمة');
        }
      }, 900);
    } else {
      UI.showAnswerFeedback(false);
      // تسجيل الخطأ
      DB.addStudentError(state.code, state.currentDiagram);
      DB.incrementDiagramErrors(state.currentDiagram.id).catch(() => {});

      setTimeout(() => {
        document.getElementById('answer-modal').classList.add('hidden');
      }, 1200);
    }
  }

  // ---------- قسم الأخطاء ----------
  function initErrors() {
    document.getElementById('btn-go-errors').addEventListener('click', () => {
      openErrors();
    });
  }

  function openErrors() {
    Router.show('screen-student-errors');
    const errors = DB.getStudentErrors(state.code);
    const list = document.getElementById('list-student-errors');
    list.innerHTML = '';
    document.getElementById('empty-student-errors').classList.toggle('hidden', errors.length > 0);

    errors.forEach((d) => {
      const li = document.createElement('li');
      li.className = 'list-item';
      li.innerHTML = `
        <div class="list-item-title">${Utils.escapeHtml(d.name || 'رسمة')}</div>
        <span class="list-item-arrow">‹</span>`;
      li.addEventListener('click', () => {
        openDiagram(d);
      });
      list.appendChild(li);
    });
  }

  return { init, enterClasses };
})();
