/**
 * المصادقة
 */
const Auth = (() => {
  const STUDENT_CODE_KEY = 'bioatlas_student_code';
  const STUDENT_CODE_ID_KEY = 'bioatlas_student_code_id';

  // ---------- المعلم ----------
  async function teacherSignIn(email, password) {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data.user;
  }

  async function teacherSignOut() {
    await supabase.auth.signOut();
  }

  function onTeacherAuthChange(callback) {
    supabase.auth.onAuthStateChange((event, session) => {
      callback(session?.user || null);
    });
  }

  async function getCurrentUser() {
    const { data: { user } } = await supabase.auth.getUser();
    return user;
  }

  async function changePassword(newPassword) {
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) throw error;
  }

  // ---------- الطالب ----------
  function getStudentCode() {
    return localStorage.getItem(STUDENT_CODE_KEY);
  }

  function getStudentCodeId() {
    return localStorage.getItem(STUDENT_CODE_ID_KEY);
  }

  function setStudentCode(code, id) {
    localStorage.setItem(STUDENT_CODE_KEY, code);
    if (id) localStorage.setItem(STUDENT_CODE_ID_KEY, id);
  }

  function clearStudentCode() {
    localStorage.removeItem(STUDENT_CODE_KEY);
    localStorage.removeItem(STUDENT_CODE_ID_KEY);
  }

  return {
    teacherSignIn,
    teacherSignOut,
    onTeacherAuthChange,
    getCurrentUser,
    changePassword,
    getStudentCode,
    getStudentCodeId,
    setStudentCode,
    clearStudentCode,
  };
})();
