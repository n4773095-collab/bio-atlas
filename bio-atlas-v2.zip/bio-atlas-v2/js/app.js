/**
 * نقطة البداية
 */
document.addEventListener('DOMContentLoaded', () => {
  Teacher.init();
  Student.init();

  // مراقبة حالة المعلم
  Auth.onTeacherAuthChange((user) => {
    if (user) {
      Teacher.enterDashboard(user);
    } else {
      const current = Router.current();
      if (current && current.startsWith('screen-teacher') && current !== 'screen-teacher-login') {
        Router.show('screen-teacher-login', { resetHistory: true });
      }
    }
  });

  // إذا كان في كود طالب محفوظ
  const savedCode = Auth.getStudentCode();
  if (savedCode) {
    Student.enterClasses();
  }

  // منع الخروج بالخطأ من التطبيق عند الضغط على رجوع في الشاشة الرئيسية
  window.addEventListener('popstate', (e) => {
    // يتم التعامل معه في Router
  });
});
