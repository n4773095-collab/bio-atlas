/**
 * طبقة البيانات - Supabase
 * 
 * الجداول المطلوبة (أنشئها في Supabase):
 * 
 * classes (id, name, order_num, created_at)
 * units (id, class_id, name, order_num, created_at)
 * sections (id, unit_id, name, order_num, created_at)
 * lessons (id, section_id, name, order_num, views, created_at)
 * diagrams (id, lesson_id, name, image_url, labels jsonb, order_num, error_count, created_at)
 * student_codes (id, code, note, active, used, used_at, created_at)
 * student_errors (id, code, diagram_id, created_at)  -- اختياري لتتبع الأخطاء
 */
const DB = (() => {

  // ---------- الصفوف ----------
  async function getClasses() {
    const { data, error } = await supabase
      .from('classes')
      .select('*')
      .order('order_num', { ascending: true });
    if (error) throw error;
    return data || [];
  }

  async function addClass(name) {
    const { count } = await supabase.from('classes').select('*', { count: 'exact', head: true });
    const { data, error } = await supabase
      .from('classes')
      .insert({ name, order_num: count || 0 })
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  async function deleteClass(id) {
    // حذف متسلسل: دروس → أقسام → وحدات → صف
    const { data: units } = await supabase.from('units').select('id').eq('class_id', id);
    for (const u of (units || [])) {
      await deleteUnit(u.id);
    }
    const { error } = await supabase.from('classes').delete().eq('id', id);
    if (error) throw error;
  }

  // ---------- الوحدات ----------
  async function getUnits(classId) {
    const { data, error } = await supabase
      .from('units')
      .select('*')
      .eq('class_id', classId)
      .order('order_num', { ascending: true });
    if (error) throw error;
    return data || [];
  }

  async function addUnit(classId, name) {
    const { count } = await supabase.from('units').select('*', { count: 'exact', head: true }).eq('class_id', classId);
    const { data, error } = await supabase
      .from('units')
      .insert({ class_id: classId, name, order_num: count || 0 })
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  async function deleteUnit(id) {
    const { data: sections } = await supabase.from('sections').select('id').eq('unit_id', id);
    for (const s of (sections || [])) {
      await deleteSection(s.id);
    }
    const { error } = await supabase.from('units').delete().eq('id', id);
    if (error) throw error;
  }

  // ---------- الأقسام ----------
  async function getSections(unitId) {
    const { data, error } = await supabase
      .from('sections')
      .select('*')
      .eq('unit_id', unitId)
      .order('order_num', { ascending: true });
    if (error) throw error;
    return data || [];
  }

  async function addSection(unitId, name) {
    const { count } = await supabase.from('sections').select('*', { count: 'exact', head: true }).eq('unit_id', unitId);
    const { data, error } = await supabase
      .from('sections')
      .insert({ unit_id: unitId, name, order_num: count || 0 })
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  async function deleteSection(id) {
    const { data: lessons } = await supabase.from('lessons').select('id').eq('section_id', id);
    for (const l of (lessons || [])) {
      await deleteLesson(l.id);
    }
    const { error } = await supabase.from('sections').delete().eq('id', id);
    if (error) throw error;
  }

  // ---------- الدروس ----------
  async function getLessons(sectionId) {
    const { data, error } = await supabase
      .from('lessons')
      .select('*')
      .eq('section_id', sectionId)
      .order('order_num', { ascending: true });
    if (error) throw error;
    return data || [];
  }

  async function addLesson(sectionId, name) {
    const { count } = await supabase.from('lessons').select('*', { count: 'exact', head: true }).eq('section_id', sectionId);
    const { data, error } = await supabase
      .from('lessons')
      .insert({ section_id: sectionId, name, order_num: count || 0, views: 0 })
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  async function deleteLesson(id) {
    await supabase.from('diagrams').delete().eq('lesson_id', id);
    const { error } = await supabase.from('lessons').delete().eq('id', id);
    if (error) throw error;
  }

  async function incrementLessonViews(lessonId) {
    // زيادة المشاهدات
    const { data } = await supabase.from('lessons').select('views').eq('id', lessonId).single();
    if (data) {
      await supabase.from('lessons').update({ views: (data.views || 0) + 1 }).eq('id', lessonId);
    }
  }

  // ---------- الرسومات ----------
  async function getDiagrams(lessonId) {
    const { data, error } = await supabase
      .from('diagrams')
      .select('*')
      .eq('lesson_id', lessonId)
      .order('order_num', { ascending: true });
    if (error) throw error;
    return data || [];
  }

  async function getDiagram(id) {
    const { data, error } = await supabase
      .from('diagrams')
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  }

  async function addDiagram(lessonId, { name, image_url, labels }) {
    const { count } = await supabase.from('diagrams').select('*', { count: 'exact', head: true }).eq('lesson_id', lessonId);
    const { data, error } = await supabase
      .from('diagrams')
      .insert({
        lesson_id: lessonId,
        name: name || 'رسمة',
        image_url,
        labels: labels || [],
        order_num: count || 0,
        error_count: 0,
      })
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  async function updateDiagram(id, { name, image_url, labels }) {
    const updates = {};
    if (name !== undefined) updates.name = name;
    if (image_url !== undefined) updates.image_url = image_url;
    if (labels !== undefined) updates.labels = labels;
    const { error } = await supabase.from('diagrams').update(updates).eq('id', id);
    if (error) throw error;
  }

  async function deleteDiagram(id) {
    const { error } = await supabase.from('diagrams').delete().eq('id', id);
    if (error) throw error;
  }

  async function incrementDiagramErrors(diagramId) {
    const { data } = await supabase.from('diagrams').select('error_count').eq('id', diagramId).single();
    if (data) {
      await supabase.from('diagrams').update({ error_count: (data.error_count || 0) + 1 }).eq('id', diagramId);
    }
  }

  // ---------- رفع الصور ----------
  async function uploadImage(file) {
    const ext = file.name.split('.').pop() || 'jpg';
    const fileName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const path = `diagrams/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('diagrams')
      .upload(path, file, { cacheControl: '3600', upsert: false });

    if (uploadError) throw uploadError;

    const { data } = supabase.storage.from('diagrams').getPublicUrl(path);
    return data.publicUrl;
  }

  // ---------- أكواد الطلاب ----------
  async function getCodes() {
    const { data, error } = await supabase
      .from('student_codes')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  }

  async function generateCode(note = '') {
    // توليد فريد
    for (let attempt = 0; attempt < 10; attempt++) {
      const code = Utils.generateCode();
      const { data: existing } = await supabase
        .from('student_codes')
        .select('id')
        .eq('code', code)
        .maybeSingle();

      if (!existing) {
        const { data, error } = await supabase
          .from('student_codes')
          .insert({ code, note, active: true, used: false })
          .select()
          .single();
        if (error) throw error;
        return data;
      }
    }
    throw new Error('تعذر توليد كود فريد');
  }

  async function updateCode(id, updates) {
    const { error } = await supabase.from('student_codes').update(updates).eq('id', id);
    if (error) throw error;
  }

  async function deleteCode(id) {
    const { error } = await supabase.from('student_codes').delete().eq('id', id);
    if (error) throw error;
  }

  async function validateCode(code) {
    const { data, error } = await supabase
      .from('student_codes')
      .select('*')
      .eq('code', code.toUpperCase())
      .eq('active', true)
      .maybeSingle();
    if (error) throw error;
    return data;
  }

  async function markCodeUsed(id) {
    await supabase
      .from('student_codes')
      .update({ used: true, used_at: new Date().toISOString() })
      .eq('id', id);
  }

  // ---------- إحصائيات ----------
  async function getStats() {
    const codes = await getCodes();
    const total = codes.length;
    const used = codes.filter((c) => c.used).length;

    // أكثر الدروس رواجاً
    const { data: popular } = await supabase
      .from('lessons')
      .select('id, name, views')
      .order('views', { ascending: false })
      .limit(5);

    // أكثر الرسومات أخطاءً
    const { data: errorDiagrams } = await supabase
      .from('diagrams')
      .select('id, name, error_count')
      .order('error_count', { ascending: false })
      .limit(5);

    return {
      totalCodes: total,
      usedCodes: used,
      popularLessons: popular || [],
      errorDiagrams: (errorDiagrams || []).filter((d) => (d.error_count || 0) > 0),
    };
  }

  // ---------- أخطاء الطالب (محلياً + اختياري في السيرفر) ----------
  function getStudentErrors(code) {
    try {
      const raw = localStorage.getItem('bioatlas_errors_' + code);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  function addStudentError(code, diagram) {
    const errors = getStudentErrors(code);
    if (!errors.find((e) => e.id === diagram.id)) {
      errors.push({
        id: diagram.id,
        name: diagram.name,
        image_url: diagram.image_url,
        labels: diagram.labels,
        lesson_id: diagram.lesson_id,
      });
      localStorage.setItem('bioatlas_errors_' + code, JSON.stringify(errors));
    }
  }

  function removeStudentError(code, diagramId) {
    let errors = getStudentErrors(code);
    errors = errors.filter((e) => e.id !== diagramId);
    localStorage.setItem('bioatlas_errors_' + code, JSON.stringify(errors));
  }

  return {
    getClasses, addClass, deleteClass,
    getUnits, addUnit, deleteUnit,
    getSections, addSection, deleteSection,
    getLessons, addLesson, deleteLesson, incrementLessonViews,
    getDiagrams, getDiagram, addDiagram, updateDiagram, deleteDiagram, incrementDiagramErrors,
    uploadImage,
    getCodes, generateCode, updateCode, deleteCode, validateCode, markCodeUsed,
    getStats,
    getStudentErrors, addStudentError, removeStudentError,
  };
})();
