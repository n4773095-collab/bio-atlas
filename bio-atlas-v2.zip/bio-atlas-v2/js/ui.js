/**
 * واجهة المستخدم: Toast, Loading, Modal, Confetti
 */
const UI = (() => {
  const toastEl = () => document.getElementById('toast');
  const loadingEl = () => document.getElementById('loading-overlay');
  const loadingText = () => document.getElementById('loading-text');
  const modal = () => document.getElementById('modal');
  const answerModal = () => document.getElementById('answer-modal');

  function toast(message, type = 'info') {
    const el = toastEl();
    el.textContent = message;
    el.className = 'toast show' + (type === 'error' ? ' error' : '');
    clearTimeout(el._timer);
    el._timer = setTimeout(() => {
      el.classList.remove('show');
    }, 2800);
  }

  function showLoading(text = 'جارٍ التحميل…') {
    loadingText().textContent = text;
    loadingEl().classList.remove('hidden');
  }

  function hideLoading() {
    loadingEl().classList.add('hidden');
  }

  function promptDialog(title, placeholder = '', defaultValue = '') {
    return new Promise((resolve) => {
      const m = modal();
      document.getElementById('modal-title').textContent = title;
      const input = document.getElementById('modal-input');
      input.value = defaultValue;
      input.placeholder = placeholder;
      m.classList.remove('hidden');
      setTimeout(() => input.focus(), 100);

      const cleanup = () => {
        m.classList.add('hidden');
        document.getElementById('modal-confirm').onclick = null;
        document.getElementById('modal-cancel').onclick = null;
      };

      document.getElementById('modal-confirm').onclick = () => {
        const val = input.value.trim();
        cleanup();
        resolve(val || null);
      };
      document.getElementById('modal-cancel').onclick = () => {
        cleanup();
        resolve(null);
      };
      input.onkeydown = (e) => {
        if (e.key === 'Enter') document.getElementById('modal-confirm').click();
        if (e.key === 'Escape') document.getElementById('modal-cancel').click();
      };
    });
  }

  function askAnswer() {
    return new Promise((resolve) => {
      const m = answerModal();
      const input = document.getElementById('answer-input');
      const feedback = document.getElementById('answer-feedback');
      input.value = '';
      feedback.className = 'answer-feedback hidden';
      feedback.textContent = '';
      m.classList.remove('hidden');
      setTimeout(() => input.focus(), 150);

      const cleanup = (result) => {
        m.classList.add('hidden');
        document.getElementById('answer-submit').onclick = null;
        document.getElementById('answer-cancel').onclick = null;
        resolve(result);
      };

      document.getElementById('answer-submit').onclick = () => {
        cleanup(input.value.trim());
      };
      document.getElementById('answer-cancel').onclick = () => {
        cleanup(null);
      };
      input.onkeydown = (e) => {
        if (e.key === 'Enter') document.getElementById('answer-submit').click();
        if (e.key === 'Escape') document.getElementById('answer-cancel').click();
      };
    });
  }

  function showAnswerFeedback(isCorrect) {
    const feedback = document.getElementById('answer-feedback');
    feedback.classList.remove('hidden');
    if (isCorrect) {
      feedback.className = 'answer-feedback correct';
      feedback.textContent = '✓ صحيح! أحسنت';
    } else {
      feedback.className = 'answer-feedback wrong';
      feedback.textContent = '✗ غلط، حاول مرة ثانية';
    }
  }

  // Confetti بسيط
  function confetti() {
    const canvas = document.getElementById('confetti-canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles = [];
    const colors = ['#1B5E3B', '#2E7D4F', '#4CAF70', '#81C784', '#C8E6C9', '#FFD54F'];

    for (let i = 0; i < 80; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height - canvas.height,
        w: Math.random() * 8 + 4,
        h: Math.random() * 4 + 2,
        color: colors[Math.floor(Math.random() * colors.length)],
        speed: Math.random() * 3 + 2,
        angle: Math.random() * 6.28,
        spin: Math.random() * 0.2 - 0.1,
      });
    }

    let frame = 0;
    function animate() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        p.y += p.speed;
        p.x += Math.sin(p.angle) * 1.5;
        p.angle += p.spin;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.angle);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        ctx.restore();
      });
      frame++;
      if (frame < 90) {
        requestAnimationFrame(animate);
      } else {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
    }
    animate();
  }

  return {
    toast,
    showLoading,
    hideLoading,
    promptDialog,
    askAnswer,
    showAnswerFeedback,
    confetti,
  };
})();
