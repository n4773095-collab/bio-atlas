/**
 * إدارة التنقل بين الشاشات + دعم زر الرجوع في الموبايل
 */
const Router = (() => {
  const historyStack = [];
  let currentScreen = null;

  function show(screenId, { resetHistory = false, push = true } = {}) {
    const next = document.getElementById(screenId);
    if (!next) return;

    // إخفاء الشاشة الحالية
    document.querySelectorAll('.screen.active').forEach((s) => {
      s.classList.remove('active');
    });

    next.classList.add('active');

    if (resetHistory) {
      historyStack.length = 0;
    }

    if (push && currentScreen && currentScreen !== screenId) {
      historyStack.push(currentScreen);
    }

    currentScreen = screenId;

    // تحديث history API عشان زر الرجوع في الموبايل
    try {
      window.history.pushState({ screen: screenId }, '', '#' + screenId);
    } catch (e) {}
  }

  function back() {
    if (historyStack.length === 0) {
      // إذا ما في تاريخ، نرجع لشاشة الدخول المناسبة
      const isTeacher = currentScreen && currentScreen.startsWith('screen-teacher');
      show(isTeacher ? 'screen-teacher-login' : 'screen-student-login', { resetHistory: true, push: false });
      return false;
    }
    const prev = historyStack.pop();
    show(prev, { push: false });
    return true;
  }

  function current() {
    return currentScreen;
  }

  // استماع لزر الرجوع في المتصفح/الموبايل
  window.addEventListener('popstate', (e) => {
    if (historyStack.length > 0) {
      const prev = historyStack.pop();
      document.querySelectorAll('.screen.active').forEach((s) => s.classList.remove('active'));
      const el = document.getElementById(prev);
      if (el) {
        el.classList.add('active');
        currentScreen = prev;
      }
    }
  });

  // ربط كل أزرار data-back
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-back]');
    if (btn) {
      e.preventDefault();
      back();
    }
  });

  return { show, back, current };
})();
