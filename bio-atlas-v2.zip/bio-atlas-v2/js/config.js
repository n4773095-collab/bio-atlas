/**
 * إعدادات Supabase
 */
const SUPABASE_URL = 'https://uynznjutbvenjnaawlsh.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_N_wJFRg6b8f_ZQMakIU5MQ_pB1tbiPC';

// تهيئة Supabase
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
