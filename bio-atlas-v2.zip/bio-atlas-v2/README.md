# أطلس الأحياء - النسخة الجديدة

تطبيق تعليمي تفاعلي لرسومات علم الأحياء.

## الميزات

- تسلسل: صف → وحدة → قسم → درس → رسومات
- المعلم يرفع الرسمة ويرسم شرائط تغطية ويكتب المسمّى
- الطالب يكتب المسمّى (مع تسامح بخطأ حرف + تجاهل التشكيل)
- احتفال عند الإجابة الصحيحة
- قسم الأخطاء للطالب
- أكواد لا نهائية + تعديل الاسم + معرفة إذا استخدم
- إحصائيات (أكثر الدروس رواجاً + أكثر الرسومات أخطاءً)
- تصميم أخضر وأبيض هادئ
- كامل بالعربي

## إعداد Supabase (مجاني)

1. ادخل [supabase.com](https://supabase.com) وأنشئ مشروع
2. من **SQL Editor** نفّذ هذا الكود لإنشاء الجداول:

```sql
-- الصفوف
create table classes (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  order_num int default 0,
  created_at timestamptz default now()
);

-- الوحدات
create table units (
  id uuid primary key default gen_random_uuid(),
  class_id uuid references classes(id) on delete cascade,
  name text not null,
  order_num int default 0,
  created_at timestamptz default now()
);

-- الأقسام
create table sections (
  id uuid primary key default gen_random_uuid(),
  unit_id uuid references units(id) on delete cascade,
  name text not null,
  order_num int default 0,
  created_at timestamptz default now()
);

-- الدروس
create table lessons (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references sections(id) on delete cascade,
  name text not null,
  order_num int default 0,
  views int default 0,
  created_at timestamptz default now()
);

-- الرسومات
create table diagrams (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid references lessons(id) on delete cascade,
  name text default 'رسمة',
  image_url text,
  labels jsonb default '[]',
  order_num int default 0,
  error_count int default 0,
  created_at timestamptz default now()
);

-- أكواد الطلاب
create table student_codes (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  note text default '',
  active boolean default true,
  used boolean default false,
  used_at timestamptz,
  created_at timestamptz default now()
);

-- تفعيل Row Level Security (مهم)
alter table classes enable row level security;
alter table units enable row level security;
alter table sections enable row level security;
alter table lessons enable row level security;
alter table diagrams enable row level security;
alter table student_codes enable row level security;

-- سياسات مؤقتة للتطوير (افتح القراءة والكتابة للجميع)
-- لاحقاً نضيقها أكثر
create policy "Allow all" on classes for all using (true) with check (true);
create policy "Allow all" on units for all using (true) with check (true);
create policy "Allow all" on sections for all using (true) with check (true);
create policy "Allow all" on lessons for all using (true) with check (true);
create policy "Allow all" on diagrams for all using (true) with check (true);
create policy "Allow all" on student_codes for all using (true) with check (true);
```

3. من **Storage** أنشئ bucket اسمه `diagrams` واجعله Public.
4. من **Authentication** → Users أنشئ مستخدم للمعلم (إيميل + كلمة سر).
5. من **Settings → API** انسخ:
   - Project URL
   - anon public key
6. الصقهم في ملف `js/config.js`

## التشغيل

افتح `index.html` في المتصفح أو ارفعه على GitHub Pages / Cloudflare Pages.

## ملاحظات

- كل شيء مجاني ضمن حدود Supabase Free.
- عدد الصور المحدود (رسومات الكتاب) يبقى مرتاحاً جداً ضمن المجاني.
